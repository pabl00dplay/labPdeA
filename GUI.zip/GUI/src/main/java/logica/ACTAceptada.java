
package main.java.logica;

public enum ACTAceptada {
    AGREGADA, RECHAZADA, ACEPTADA
}
